<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExamFormat extends Model
{
    use HasFactory;

    protected $fillable = [
        'format',
        'created_by',
        'updated_by',
        'status',
    ];

    public function exams()
    {
        return $this->hasMany(Exam::class);
    }

    public function createdBy()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function updatedBy()
    {
        return $this->belongsTo(User::class, 'updated_by');
    }
}
